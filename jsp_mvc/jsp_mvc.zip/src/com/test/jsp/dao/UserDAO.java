package com.test.jsp.dao;

import java.util.List;

import com.test.jsp.vo.UserInfo;

public interface UserDAO {
	public void login();
	public List<UserInfo> selectUserList();
	public void logout();
	public void join();
	public void out();

}

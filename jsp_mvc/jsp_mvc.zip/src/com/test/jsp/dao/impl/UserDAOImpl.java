package com.test.jsp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.test.jsp.common.DBCon;
import com.test.jsp.dao.UserDAO;
import com.test.jsp.vo.UserInfo;

public class UserDAOImpl implements UserDAO {
	private Connection con;
	@Override
	public void login() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<UserInfo> selectUserList() {
		List<UserInfo> userList = new ArrayList<UserInfo>();
		con = DBCon.getCon();
		try {
			PreparedStatement ps = con.prepareStatement("select * from user_info");
			ResultSet rs = ps.executeQuery();
			UserInfo ui;
			while(rs.next()) {
				ui = new UserInfo();
				ui.setAddress(rs.getString("address"));
				ui.setHobby(rs.getString("hobby"));
				ui.setId(rs.getString("id"));
				ui.setName(rs.getString("name"));
				ui.setNum(rs.getInt("num"));
				ui.setPwd(rs.getString("pwd"));
				ui.setTrans(rs.getString("trans"));
				userList.add(ui);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userList;
	}

	@Override
	public void logout() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void join() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void out() {
		// TODO Auto-generated method stub
		
	}

}

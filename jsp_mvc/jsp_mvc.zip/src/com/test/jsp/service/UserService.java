package com.test.jsp.service;

import java.util.List;

import com.test.jsp.vo.UserInfo;

public interface UserService {
	public void login();
	public List<UserInfo> getUserList();
	public void logout();
	public void join();
	public void out();
}

package com.test.jsp.service.impl;

import java.util.List;

import com.test.jsp.dao.UserDAO;
import com.test.jsp.dao.impl.UserDAOImpl;
import com.test.jsp.service.UserService;
import com.test.jsp.vo.UserInfo;

public class UserServiceImpl implements UserService {
	UserDAO udao = new UserDAOImpl();
	@Override
	public void login() {
		// TODO Auto-generated method stub
	}

	@Override
	public List<UserInfo> getUserList() {
		return udao.selectUserList();
	}

	@Override
	public void logout() {
		// TODO Auto-generated method stub

	}

	@Override
	public void join() {
		// TODO Auto-generated method stub

	}

	@Override
	public void out() {
		// TODO Auto-generated method stub

	}

}
